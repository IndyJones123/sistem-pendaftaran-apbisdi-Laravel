<svg viewBox="0 0 318 318" width="318" height="318">
        <image href="{{ asset('apbisdi.png') }}" width="318" height="318" />
    </svg>