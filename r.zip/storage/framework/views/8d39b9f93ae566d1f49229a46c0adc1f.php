<?php echo e($slot); ?>

<?php /**PATH D:\Project\Paid\sistem-pendaftaran-apbisdi-Laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>