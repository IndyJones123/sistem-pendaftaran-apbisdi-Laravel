

<?php $__env->startSection('konten'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\PT\pt\resources\views/main/pt/dashboard.blade.php ENDPATH**/ ?>