<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BiayaController extends Controller
{
    //
}
