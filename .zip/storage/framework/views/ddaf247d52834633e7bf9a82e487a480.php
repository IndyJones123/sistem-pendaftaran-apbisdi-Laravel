<svg viewBox="0 0 318 318" width="318" height="318">
        <image href="<?php echo e(asset('apbisdi.png')); ?>" width="318" height="318" />
    </svg><?php /**PATH D:\Project\Paid\sistem-pendaftaran-apbisdi-Laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>