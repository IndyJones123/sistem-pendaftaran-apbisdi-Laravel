import './bootstrap';
import '../css/app.css';
import 'preline';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
