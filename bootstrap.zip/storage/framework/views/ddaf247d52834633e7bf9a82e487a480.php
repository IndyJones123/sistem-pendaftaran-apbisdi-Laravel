<svg viewBox="0 0 318 318" class="w-12 h-12 sm:w-12 sm:h-12 lg:w-80 lg:h-80 mt-5 mr-5">
    <image href="<?php echo e(asset('apbisdi.png')); ?>" width="318" height="318" />
</svg>
<?php /**PATH D:\Project\Paid\sistem-pendaftaran-apbisdi-Laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>