<!-- resources/views/emails/pt_approved.blade.php -->
<p>Dear <?php echo e($data->namakaprodi); ?>,</p>

<p>Mohon maaf, permohonan Anda untuk Universitas atas nama <?php echo e($data->namapt); ?> telah ditolak.</p>
<p>Mohon lengkapi berkas dan data dengan benar. Hubungi kami untuk keterangan lebih lanjut.</p>

<p>Terima kasih Atas Perhatiannya</p>
<?php /**PATH D:\Project\Paid\sistem-pendaftaran-apbisdi-Laravel\resources\views/emails/pt_disapprove.blade.php ENDPATH**/ ?>