<?php

namespace App\Services;

class Generate {
    
}